var searchData=
[
  ['bits_5fper_5fpixel',['BITS_PER_PIXEL',['../class_adafruit_canvas_ops.html#af62e9d7f0736b51ea8fd3a680ccea70a',1,'AdafruitCanvasOps::BITS_PER_PIXEL()'],['../class_nano_canvas_ops.html#a8c2cedb18e71493a370c01147dbed846',1,'NanoCanvasOps::BITS_PER_PIXEL()']]],
  ['bottom',['bottom',['../struct_s_s_d1306___r_e_c_t.html#ac6f2761573966ed9540d9ac66cf1b471',1,'SSD1306_RECT']]]
];
