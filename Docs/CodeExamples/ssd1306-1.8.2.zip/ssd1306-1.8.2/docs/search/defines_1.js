var searchData=
[
  ['gray_5fcolor4',['GRAY_COLOR4',['../nano__gfx__types_8h.html#afd58e53d7074f56bbd024730c0f24067',1,'nano_gfx_types.h']]]
];
